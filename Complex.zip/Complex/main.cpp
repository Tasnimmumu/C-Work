#include <iostream>
using namespace std;
#include "Complex.h"
int main()
{
    Complex num(2,1);
    Complex num(3,1);
    num1.Print();
    num.Print();
    return 0;
}
